import React, { Component } from 'react';
import './../App.css';

import getWeather from '../services/getWeather';



class App extends Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.fm = new getWeather();
  }
  handleOptionClick = (e) => {
    console.log("Dans handleOptionClick");
    // console.log(e.target);
    //* On doit recupérer la valeur de l'option sélectionnée
    let value = e.target.options[e.target.selectedIndex].value;
    //* On doit appeler la fonction getWeather avec la valeur de l'option
    //* On doit mettre à jour le state avec la valeur de l'option
    // console.log("value : " + value);
    this.getWeather(value);

  };

  componentDidMount() {
    console.log("Dans componentDidMount");
    //* On doit appeler la fonction getWeather avec la valeur de l'option
    //* On doit mettre à jour le state avec la valeur de l'option
    this.getWeather("Paris");
  }

  render() {
    return (
      <div className="App">
        <h1>Meteo</h1>
        <select onChange={this.handleOptionClick}>
          <option value="Paris">Paris</option>
          <option value="Lyon">Lyon</option>
          <option value="Marseille">Marseille</option>
          <option value="Toulouse">Toulouse</option>
          <option value="Nice">Nice</option>
          <option value="Londres">Londres</option>
          <option value="New York">New York</option>
          <option value="Moscou">Moscou</option>
          <option value="Kiev">Kiev</option>
        </select>
        <div>
          <p>
            Ville : {this.state.ville} - Pays : {this.state.country}
          </p>
          <p>
            Température : {this.state.temperature} °C
          </p>
          <p>
            Vitesse du vent : {this.state.km} km/h
          </p>
          <p>
            Risque de pluie : {this.state.cloudiness} %
          </p>
          <p>
            Commentaire : {this.state.commentaire}
          </p>
        </div>
        <div>
          <img src={this.state.countryFlag}></img>
        </div>
      </div>
    );
  }
  getWeather = (town) => {
    console.log("Dans getWeather");
    console.log("town : " + town);
    this.fm.coordinatesTown(town)
      .then(data => {
        console.log("data : " + data);
        this.setState(data);
      })
      .catch(error => {
        console.log("error : " + error);
      });
  }
}
export default App;
