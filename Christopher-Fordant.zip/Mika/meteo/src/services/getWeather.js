export default class getWeather {
  constructor(props) {
    this.url_basis = "https://api.openweathermap.org/data/2.5/weather?q=";
  }
  coordinatesTown = (town) => {
    let APIKEY = '&appid=5aca9dae9e59526a5ff9c19c21167752';
    let optionMeteo = '&units=metric&lang=fr';
    let url = this.url_basis + town + APIKEY + optionMeteo;
    console.log("url : " + url);
    return fetch(url)
      .then(response => response.json())
      .then(data => {
        let km = Math.ceil((Number(data.wind.speed) * 3.6), 2);
        let comm = data.weather[0].description;
        let temperature = Math.round(data.main.temp);
        let country = data.sys.country.toLowerCase();
        let commentaire = comm.replace(/\w\S*/g, function (txt) { return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase(); });
        let countryFlag = `https://flagcdn.com/120x90/${country}.png`;
        let ville = data.name;
        let cloudiness = data.clouds.all;
        return {
          ville: ville,
          country: country,
          countryFlag: countryFlag,
          temperature: temperature,
          km: km,
          cloudiness: cloudiness,
          commentaire: commentaire

        }
        console.log("data : " + data);
        return data;
      })
      .catch(error => {
        console.log("error : " + error);
      });
  }
}

